package com.example.networkcalltest;

public class VolumeInfo {
    String title;
    String subtitle;
    ImageLinks imageLinks;
}
