package com.example.networkcalltest;

public class BookItem {
    VolumeInfo volumeInfo;
}
