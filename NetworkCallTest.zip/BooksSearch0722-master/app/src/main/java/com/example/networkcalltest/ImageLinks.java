package com.example.networkcalltest;

public class ImageLinks {
    String smallThumbnail;
}
