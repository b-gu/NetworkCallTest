package com.example.networkcalltest;

interface CustomListener {
    void itemClicked(BookItem item);
}
