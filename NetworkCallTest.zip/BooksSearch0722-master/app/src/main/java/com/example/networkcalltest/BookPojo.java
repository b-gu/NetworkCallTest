package com.example.networkcalltest;

import java.util.List;

public class BookPojo {
    List<BookItem> items;
}
